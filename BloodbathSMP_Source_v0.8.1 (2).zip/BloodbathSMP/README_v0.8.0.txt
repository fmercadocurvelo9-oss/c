BLOODBATH SMP — CHANGELOG v0.8.0

CONTENIDO NUEVO
- 10 objetos especiales adicionales: Corazón Abismal, Tótem de Tormenta, Campana Fúnebre, Ojo del Cazador, Vial Hemático, Orbe del Vacío, Marcaescarcha, Farol de Almas, Amuleto de Ruptura y Máscara Ósea.
- Habilidades activables con clic derecho y enfriamientos por jugador/objeto.
- 6 variantes de élites: Infectado Carmesí, Acechador Umbrío, Portador de Plaga, Carcelero Óseo, Devorador de Almas y Ejecutor Sangriento.
- Las élites tienen efectos distintos al golpear: veneno, ceguera, wither, lentitud o debilidad.
- Algunas élites pueden brillar desde el día 20 para distinguirlas en combate.
- Recetas nuevas para Corazón Abismal, Tótem de Tormenta, Campana Fúnebre, Ojo del Cazador, Marcaescarcha, Farol de Almas y Amuleto de Ruptura.
- 10 PNG adicionales de iconos recoloreados para el resource pack.
- Si un jugador muere mientras Death Rain está activa, la duración aumenta de forma exponencial según el día, con límite configurable.

IMPORTANTE
- Esto sigue siendo código fuente; no es un JAR compilado.
- Entorno disponible para esta preparación: Java 21, no Java 25; no se pudo compilar ni probar en Paper 26.3.
- Las texturas PNG existen, pero su conexión con modelos de objetos de Minecraft 26.3 no está validada. No afirmar que se mostrarán automáticamente dentro del juego.
- La mecánica de élites usa entidades vanilla con nombres/efectos, no modelos 3D nuevos.


BLOODBATH SMP v0.8.1 — DROPS DE MOBS Y CRAFTEOS

ÉLITES (nombres que contienen “Bloodbath”, desde el día 5 según la probabilidad de élite):
- 100%: Lingote de Sangre (NETHERITE_SCRAP).
- Fragmento Óseo (BONE): 35% + hasta 25 puntos porcentuales según el día.
- Esencia Espectral (PHANTOM_MEMBRANE): 22% + bonus progresivo.
- Glándula de Plaga (SPIDER_EYE): 16% + bonus progresivo.
- Fragmento Abismal (ECHO_SHARD): 8% + medio bonus progresivo.
- Ascua de Alma (BLAZE_POWDER): 12% + medio bonus progresivo.
- Núcleo de Tormenta (PRISMARINE_CRYSTALS): desde día 25, 5% + medio bonus progresivo.

MOBS DE LA DEATH RAIN (“Lluvia de Sangre”):
- Fragmento de Sangre (ROTTEN_FLESH): 30% + bonus progresivo.
- Fragmento Óseo (BONE): 18% + bonus progresivo.
- Ascua de Alma (BLAZE_POWDER): desde día 15, 8% + medio bonus progresivo.

RECETAS NUEVAS/ACTUALIZADAS:
- Lingote de Sangre: R F R / R _ R / _ _ _ (R=carne podrida, F=polvo de blaze).
- Espada Carmesí: R / R / S (R=Lingote de Sangre, S=palo).
- Yelmo Espectral: W W W / W _ W / _ _ _ (W=membrana de phantom).
- Daga Espectral: _ A _ / _ W _ / _ _ _ (A=corazón del mar, W=membrana de phantom).
- Quebrantahuesos: B B _ / B S _ / _ S _ (B=hueso, S=palo).
- Núcleo Abismal: E D E / D C D / E D E (E=fragmento de eco, D=diamante, C=cristales de prismarina).

IMPORTANTE: las recetas de Bukkit comprueban el MATERIAL, no el nombre/PDC del ingrediente. Por eso los materiales base normales también sirven para estas recetas; los nombres personalizados identifican los drops y sus usos en el juego, pero no bloquean el crafteo a solo esos drops. Los drops especiales se añaden al morir a los mobs nombrados por el plugin. No se ha confirmado compilación o prueba en Paper 26.3/Java 25.

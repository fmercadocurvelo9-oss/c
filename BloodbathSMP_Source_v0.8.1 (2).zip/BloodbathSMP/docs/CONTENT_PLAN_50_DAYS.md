# Bloodbath SMP — contenido objetivo (50 días)

## Regla de progresión
- El día se cambia manualmente con `/bloodbath day <1-50>`.
- No se permite día 0 ni día 51.
- Hitos: 10, 20, 30, 40 y 50.
- Los valores de este documento son diseño; no implica que cada sistema ya esté implementado.

## Etapas
| Días | Etapa | Contenido planeado |
|---|---|---|
| 1–5 | La infección | Zombis/esqueletos base; materiales iniciales; Espada Carmesí de entrada |
| 6–10 | Primer brote | Escalado moderado; élites iniciales; jefe del día 10 y Núcleo Carmesí |
| 11–20 | La sangre despierta | Infectados y Acechadores; set Espectral; jefe del día 20 |
| 21–30 | La masacre | Guardián Abismal; materiales raros; set Abismal; jefe del día 30 |
| 31–40 | Extinción | Variantes corruptas, incursiones y objetos de alto nivel; jefe del día 40 |
| 41–49 | Última noche | Enemigos de élite más frecuentes, recursos finales y preparación del evento final |
| 50 | Bloodbath | Evento final y jefe final; recompensas de cierre configurables |

## Catálogo inicial de ítems
- `bloodblade`: Espada Carmesí; arma inicial especial.
- `spectral_dagger`: Daga Espectral; habilidad de movilidad/evasión prevista.
- `bonebreaker`: Quebrantahuesos; bonificación prevista contra élites.
- `blood_ingot`: Lingote de Sangre; material de crafteo.
- `abyssal_core`: Núcleo Abismal; material de jefes/endgame.
- `wraith_helmet`: Yelmo Espectral; pieza inicial del set Espectral.

## Crafteos objetivo
Los crafteos definitivos deben usar ítems validados por PersistentDataContainer, no solo materiales vanilla renombrados. Cada receta debe quedar registrada con NamespacedKey y retirarse limpiamente al deshabilitar el plugin.

## Criterios para considerar terminado un contenido
1. La habilidad está implementada y tiene cooldown si corresponde.
2. El ítem tiene ID interno y no se falsifica renombrando un objeto vanilla.
3. Tiene textura/modelo enlazados en el resource pack.
4. Tiene receta o método de obtención explícito.
5. Se prueba en servidor Paper objetivo con Java 25 y clientes que usen el pack.

## Pendiente técnico
El código actual no debe anunciarse como release final. Falta confirmar el artefacto exacto de Paper 26.3, validar el pack format de esa versión, completar modelos/armaduras y compilar/probar con JDK 25.

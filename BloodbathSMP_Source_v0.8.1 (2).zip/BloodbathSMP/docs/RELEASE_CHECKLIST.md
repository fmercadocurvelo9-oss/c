# Release checklist — Bloodbath SMP

- [ ] Build with JDK 25.
- [ ] Resolve a published Paper API version matching Minecraft 26.3.
- [ ] Compile with Maven and fix all API errors.
- [ ] Boot a clean Paper 26.3 test server.
- [ ] Verify `/bloodbath day 1`, `/bloodbath day 50`, and rejection of 0/51.
- [ ] Verify recipes, persistent item IDs, drops and cooldown behavior.
- [ ] Verify global death and totem broadcasts.
- [ ] Verify resource-pack metadata against Minecraft 26.3.
- [ ] Verify all item models and armor textures in a client.
- [ ] Verify heart glyph rendering and animation for all online players.
- [ ] Test performance with many mobs and repeated events.

Do not call a ZIP a JAR or describe untested features as complete.

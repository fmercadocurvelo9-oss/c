# v0.5.0 implementation status

## Implemented in source
- Manual day setting, restricted to 1–50.
- Custom item identity via a plugin PersistentDataContainer string key.
- Three right-click abilities with per-player, per-item cooldowns:
  - Espada Carmesí: Strength II for 5 seconds and Resistance I for 3 seconds; 25-second cooldown.
  - Daga Espectral: directional dash and 1.5 seconds of invisibility; 12-second cooldown.
  - Quebrantahuesos: 3 damage plus Weakness II for 5 seconds and Slowness II for 2.5 seconds; 18-second cooldown.
- Test item command grants all five draft items and the spectral helmet.

## Still incomplete
- Exact Paper 26.3 API coordinate and JDK 25 compile/runtime validation.
- Correct current pack metadata and item model definitions for the exact 26.3 client.
- Armor texture/model layers and all custom mob models.
- Dedicated boss entities/encounters at days 10/20/30/40/50.
- Recipes based on validated custom ingredients (vanilla crafting recipes alone cannot require custom PDC ingredients).
- Animated center-screen heart: current source triggers a font glyph, but the animated glyph/font integration is not yet completed and verified.

Do not describe these pending items as complete.

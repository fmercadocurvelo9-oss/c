package com.kravenn.bloodbath;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.damage.DamageSource;
import org.bukkit.entity.Player;
import org.bukkit.entity.Zombie;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.SpawnCategory;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.event.block.Action;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityResurrectEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;
import java.util.List;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class BloodbathSMP extends JavaPlugin implements Listener {
    private static final String DEATH_MESSAGE =
        "Una luce si è spenta, le ombre ne reclamano il nome e il mondo perde un'altra anima nel suo eterno silenzio.";
    private final Map<UUID, DamageSnapshot> recentDamage = new ConcurrentHashMap<>();
    private final Map<String, Long> abilityCooldowns = new ConcurrentHashMap<>();
    private NamespacedKey itemIdKey;
    private BukkitTask deathRainTask;
    private BukkitTask deathRainStopTask;
    private long deathRainEndMillis = 0L;
    private long lastDeathRainDay = -1;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        itemIdKey = new NamespacedKey(this, "bloodbath_item_id");
        if (getCommand("bloodbath") == null) { getLogger().severe("Missing /bloodbath command in plugin.yml"); Bukkit.getPluginManager().disablePlugin(this); return; }
        Bukkit.getPluginManager().registerEvents(this, this);
        getCommand("bloodbath").setExecutor((sender, command, label, args) -> {
            if (!sender.hasPermission("bloodbath.admin")) { sender.sendMessage("Sin permiso."); return true; }
            if (args.length == 2 && args[0].equalsIgnoreCase("day")) {
                int day;
                try { day = Integer.parseInt(args[1]); } catch (NumberFormatException ex) { sender.sendMessage("Uso: /bloodbath day <1-50>"); return true; }
                if (day < 1 || day > 50) { sender.sendMessage("El día debe estar entre 1 y 50."); return true; }
                getConfig().set("current-day", day); saveConfig();
                Bukkit.broadcast(Component.text("☠ BLOODBATH SMP entra en el día " + day + ".", TextColor.fromHexString("#D71920")));
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("deathrain")) {
                startDeathRain(true);
                sender.sendMessage("§4Death Rain iniciada.");
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("stoprain")) {
                stopDeathRain(true);
                sender.sendMessage("§7Death Rain detenida.");
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("recipes")) {
                sender.sendMessage("§4§lBLOODBATH SMP — CRAFTEOS");
                sender.sendMessage("§cEspada Carmesí: R / R / S (R=Lingote de Sangre de élite, S=Stick)");
                sender.sendMessage("§8Yelmo Espectral: WWW / W_W / ___ (W=Esencia Espectral de élite)");
                sender.sendMessage("§5Daga Espectral: _A_ / _W_ / ___ (A=Núcleo Abismal, W=Esencia Espectral)");
                sender.sendMessage("§6Quebrantahuesos: BB_ / BS_ / _S_ (B=Fragmento Óseo, S=Stick)");
                sender.sendMessage("§5Núcleo Abismal: 3 fragmentos de eco + 2 diamantes + 1 corazón del mar; ver RECIPES_AND_TEXTURE_PACK.txt");
                sender.sendMessage("§7Usa el resource pack incluido para los iconos. Algunas texturas requieren vincularse al modelo del objeto en el pack.");
                return true;
            }
            if (args.length == 1 && args[0].equalsIgnoreCase("giveitems")) {
                if (!(sender instanceof Player player)) { sender.sendMessage("Solo jugadores pueden usar esto."); return true; }
                player.getInventory().addItem(makeItem("bloodblade", Material.IRON_SWORD, "§4Espada Carmesí", "§7Clic derecho: Furia Carmesí."));
                player.getInventory().addItem(makeItem("spectral_dagger", Material.IRON_SWORD, "§8Daga Espectral", "§7Clic derecho: Paso espectral."));
                player.getInventory().addItem(makeItem("bonebreaker", Material.IRON_AXE, "§6Quebrantahuesos", "§7Clic derecho: Golpe debilitante."));
                player.getInventory().addItem(makeItem("blood_ingot", Material.NETHERITE_SCRAP, "§cLingote de Sangre", "§7Material de fabricación de Bloodbath."));
                player.getInventory().addItem(makeItem("abyssal_core", Material.HEART_OF_THE_SEA, "§5Núcleo Abismal", "§7Un núcleo oscuro de energía."));
                player.getInventory().addItem(makeItem("wraith_helmet", Material.IRON_HELMET, "§8Yelmo Espectral", "§7Protección recuperada de la noche."));
                sender.sendMessage("Ítems de prueba entregados."); return true;
            }
            sender.sendMessage("Uso: /bloodbath day <1-50> | /bloodbath deathrain | /bloodbath stoprain | /bloodbath giveitems"); return true;
        });
        registerRecipes();
        getLogger().info("Bloodbath SMP enabled. Manual progression day 1-50; exponential difficulty and mob controls enabled.");
    }

    @Override
    public void onDisable() {
        if (deathRainTask != null) deathRainTask.cancel();
        if (deathRainStopTask != null) deathRainStopTask.cancel();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        Bukkit.broadcast(Component.text(DEATH_MESSAGE, TextColor.fromHexString("#D71920")));
        Bukkit.broadcast(Component.text("☠ " + dead.getName() + " ha perdido su última luz.", NamedTextColor.DARK_RED));

        // Title text is supported for every client. The animated heart graphic is supplied
        // separately by the resource pack's custom font glyph.
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            viewer.sendTitle(" ", "\uE000", 5, 50, 10);
        }
        int day = getConfig().getInt("current-day", 1);
        if (day >= 11 && Math.random() < Math.min(0.55, 0.12 + day * 0.008)) {
            Bukkit.broadcast(Component.text("§4La sangre reclama otra alma...", NamedTextColor.DARK_RED));
        }
        recentDamage.remove(dead.getUniqueId());
    }

    @EventHandler
    public void onSpawn(CreatureSpawnEvent event) {
        LivingEntity mob = event.getEntity();
        int day = getConfig().getInt("current-day", 1);
        String reason = event.getSpawnReason().name();

        // Spawn egg policy: configurable, including dispenser/creative placement.
        if (event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.SPAWNER_EGG
                && !getConfig().getBoolean("mob-control.spawn-eggs.enabled", true)) {
            event.setCancelled(true);
            return;
        }

        // Natural spawn control by category and per-world configured caps.
        if (event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.NATURAL) {
            if (mob instanceof Monster && !getConfig().getBoolean("mob-control.natural-hostile.enabled", true)) {
                event.setCancelled(true); return;
            }
            if (!(mob instanceof Monster) && !getConfig().getBoolean("mob-control.natural-passive.enabled", true)) {
                event.setCancelled(true); return;
            }
            if (mob instanceof Monster) {
                int cap = getConfig().getInt("mob-control.natural-hostile.max-loaded-per-world", 180);
                long loaded = mob.getWorld().getLivingEntities().stream().filter(e -> e instanceof Monster).count();
                if (cap >= 0 && loaded >= cap) { event.setCancelled(true); return; }
            }
        }

        if (day < getConfig().getInt("difficulty.scaling-start-day", 1)) return;
        if (!(mob instanceof Monster)) return;
        double healthMultiplier = exponentialMultiplier(day, "difficulty.health");
        double damageMultiplier = exponentialMultiplier(day, "difficulty.damage");
        AttributeInstance maxHealth = mob.getAttribute(Attribute.MAX_HEALTH);
        if (maxHealth != null) {
            double base = maxHealth.getBaseValue();
            double scaled = Math.min(getConfig().getDouble("difficulty.health.cap", 160.0), base * healthMultiplier);
            maxHealth.setBaseValue(Math.max(1.0, scaled));
            mob.setHealth(Math.min(mob.getHealth(), maxHealth.getBaseValue()));
            mob.setHealth(maxHealth.getBaseValue());
        }
        AttributeInstance attack = mob.getAttribute(Attribute.ATTACK_DAMAGE);
        if (attack != null) {
            double scaledDamage = Math.min(getConfig().getDouble("difficulty.damage.cap", 40.0), attack.getBaseValue() * damageMultiplier);
            attack.setBaseValue(Math.max(1.0, scaledDamage));
        }

        double eliteChance = Math.min(getConfig().getDouble("difficulty.elite.chance-cap", 0.45),
                getConfig().getDouble("difficulty.elite.base-chance", 0.015) * Math.pow(getConfig().getDouble("difficulty.elite.growth", 1.095), day - 1));
        if (day >= getConfig().getInt("difficulty.elite.start-day", 5) && Math.random() < eliteChance) {
            mob.setCustomName("§4Bloodbath §c" + (mob instanceof Zombie ? "Infectado" : "Acechador"));
            mob.setCustomNameVisible(true);
            if (mob.getEquipment() != null) {
                mob.getEquipment().setItemInMainHand(new ItemStack(day >= 35 ? Material.NETHERITE_SWORD : day >= 15 ? Material.IRON_SWORD : Material.STONE_SWORD));
                mob.getEquipment().setItemInMainHandDropChance(0.0f);
            }
        }

        // Death Rain makes hostile mobs more dangerous while active.
        if (getConfig().getBoolean("death-rain.active", false)) {
            mob.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60 * 10, Math.max(0, day / 20), false, true, true));
            mob.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 60 * 10, Math.max(0, day / 25), false, true, true));
        }
    }

    private double exponentialMultiplier(int day, String path) {
        double base = getConfig().getDouble(path + ".base", 1.0);
        double growth = getConfig().getDouble(path + ".growth-per-day", 1.055);
        double cap = getConfig().getDouble(path + ".multiplier-cap", 12.0);
        return Math.max(1.0, Math.min(cap, base * Math.pow(growth, Math.max(0, day - 1))));
    }

    private void startDeathRain(boolean manual) {
        if (deathRainTask != null) deathRainTask.cancel();
        if (deathRainStopTask != null) deathRainStopTask.cancel();
        getConfig().set("death-rain.active", true);
        saveConfig();
        lastDeathRainDay = getConfig().getInt("current-day", 1);
        int initialSeconds = Math.max(30, getConfig().getInt("death-rain.duration-seconds", 180));
        deathRainEndMillis = System.currentTimeMillis() + initialSeconds * 1000L;
        for (World world : Bukkit.getWorlds()) {
            world.setStorm(true);
            world.setThundering(true);
            world.setWeatherDuration(Math.min(Integer.MAX_VALUE, initialSeconds * 20));
            world.setThunderDuration(Math.min(Integer.MAX_VALUE, initialSeconds * 20));
        }
        Bukkit.broadcast(Component.text("☠ DEATH RAIN ☠ La lluvia de sangre ha comenzado. No salgáis sin prepararos.", TextColor.fromHexString("#C00020")));
        int interval = Math.max(10, getConfig().getInt("death-rain.wave-interval-seconds", 45));
        deathRainTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            if (!getConfig().getBoolean("death-rain.active", false)) { stopDeathRain(false); return; }
            int day = getConfig().getInt("current-day", 1);
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getWorld().getEnvironment() == World.Environment.NORMAL && Math.random() < 0.55) {
                    Location spawn = player.getLocation().clone().add((Math.random() * 2 - 1) * 10, 0, (Math.random() * 2 - 1) * 10);
                    spawn.setY(player.getWorld().getHighestBlockYAt(spawn) + 1);
                    if (spawn.getBlock().isPassable() && spawn.getBlock().getLightLevel() <= 7) {
                        LivingEntity spawned = (LivingEntity) player.getWorld().spawnEntity(spawn, day >= 30 ? EntityType.HUSK : EntityType.ZOMBIE);
                        spawned.setCustomName("§4Lluvia de Sangre");
                        spawned.setCustomNameVisible(false);
                        spawned.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 20 * 60 * 5, Math.max(0, day / 20), false, true, true));
                        spawned.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 20 * 60 * 5, Math.max(0, day / 25), false, true, true));
                    }
                }
            }
        }, interval * 20L, interval * 20L);
        scheduleDeathRainStop();
    }

    private long getDeathRainExtensionMillis(int day) {
        double baseHours = getConfig().getDouble("death-rain.death-extension.base-hours", 0.25);
        double growth = getConfig().getDouble("death-rain.death-extension.growth-per-day", 1.08);
        double capHours = getConfig().getDouble("death-rain.death-extension.max-hours-per-death", 24.0);
        double hours = Math.min(capHours, baseHours * Math.pow(growth, Math.max(0, day - 1)));
        return (long) (Math.max(0.0, hours) * 3_600_000L);
    }

    private void scheduleDeathRainStop() {
        if (deathRainStopTask != null) deathRainStopTask.cancel();
        long remainingMillis = Math.max(1000L, deathRainEndMillis - System.currentTimeMillis());
        long ticks = Math.max(20L, remainingMillis / 50L);
        deathRainStopTask = Bukkit.getScheduler().runTaskLater(this, () -> {
            if (System.currentTimeMillis() >= deathRainEndMillis) stopDeathRain(false);
            else scheduleDeathRainStop();
        }, ticks);
        int seconds = (int) Math.min(Integer.MAX_VALUE / 20, Math.max(1L, remainingMillis / 1000L));
        for (World world : Bukkit.getWorlds()) {
            world.setStorm(true);
            world.setThundering(true);
            world.setWeatherDuration(seconds * 20);
            world.setThunderDuration(seconds * 20);
        }
    }

    private void stopDeathRain(boolean announce) {
        if (deathRainTask != null) { deathRainTask.cancel(); deathRainTask = null; }
        if (deathRainStopTask != null) { deathRainStopTask.cancel(); deathRainStopTask = null; }
        deathRainEndMillis = 0L;
        getConfig().set("death-rain.active", false);
        saveConfig();
        if (announce) Bukkit.broadcast(Component.text("☠ La Death Rain s'est dissipée.", TextColor.fromHexString("#888888")));
    }

    @EventHandler
    public void onMobDeath(EntityDeathEvent event) {
        LivingEntity mob = event.getEntity();
        String name = mob.getCustomName();
        if (name == null) return;
        boolean elite = name.contains("Bloodbath");
        boolean deathRainMob = name.contains("Lluvia de Sangre");
        if (!elite && !deathRainMob) return;

        int day = getConfig().getInt("current-day", 1);
        double dayBonus = Math.min(0.25, Math.max(0, day - 1) * 0.005);
        if (elite) {
            // Guaranteed core crafting material; extra drops become more likely as the 50-day run advances.
            event.getDrops().add(makeItem("blood_ingot", Material.NETHERITE_SCRAP,
                    "§cLingote de Sangre", "§7Drop élite: material para equipo carmesí."));
            if (Math.random() < 0.35 + dayBonus)
                event.getDrops().add(makeItem("bone_shard", Material.BONE,
                        "§fFragmento Óseo", "§7Drop élite: refuerza armas pesadas."));
            if (Math.random() < 0.22 + dayBonus)
                event.getDrops().add(makeItem("wraith_essence", Material.PHANTOM_MEMBRANE,
                        "§8Esencia Espectral", "§7Drop élite: ingrediente de equipo espectral."));
            if (Math.random() < 0.16 + dayBonus)
                event.getDrops().add(makeItem("plague_gland", Material.SPIDER_EYE,
                        "§2Glándula de Plaga", "§7Drop élite: ingrediente alquímico."));
            if (Math.random() < 0.08 + dayBonus / 2)
                event.getDrops().add(makeItem("abyssal_shard", Material.ECHO_SHARD,
                        "§5Fragmento Abismal", "§7Drop raro: concentra energía del vacío."));
            if (Math.random() < 0.12 + dayBonus / 2)
                event.getDrops().add(makeItem("soul_ember", Material.BLAZE_POWDER,
                        "§6Ascua de Alma", "§7Drop élite: catalizador de armas."));
            if (day >= 25 && Math.random() < 0.05 + dayBonus / 2)
                event.getDrops().add(makeItem("storm_core", Material.PRISMARINE_CRYSTALS,
                        "§bNúcleo de Tormenta", "§7Drop raro de élites avanzados."));
        } else {
            // Death Rain mobs drop smaller quantities, so the event is useful without flooding the economy.
            if (Math.random() < 0.30 + dayBonus)
                event.getDrops().add(makeItem("blood_fragment", Material.ROTTEN_FLESH,
                        "§4Fragmento de Sangre", "§7Se usa para fabricar materiales carmesíes."));
            if (Math.random() < 0.18 + dayBonus)
                event.getDrops().add(makeItem("bone_shard", Material.BONE,
                        "§fFragmento Óseo", "§7Drop de la Death Rain."));
            if (day >= 15 && Math.random() < 0.08 + dayBonus / 2)
                event.getDrops().add(makeItem("soul_ember", Material.BLAZE_POWDER,
                        "§6Ascua de Alma", "§7Catalizador poco común de la Death Rain."));
        }
    }

    private ItemStack makeItem(String id, Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        meta.setLore(java.util.List.of(lore));
        meta.getPersistentDataContainer().set(itemIdKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    @EventHandler
    public void onAbilityUse(PlayerInteractEvent event) {
        if (event.getItem() == null || event.getHand() == null) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        String id = getCustomItemId(event.getItem());
        if (id == null) return;
        Player player = event.getPlayer();
        switch (id) {
            case "bloodblade" -> {
                if (!useCooldown(player, id, 25)) return;
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, 100, 1, false, true, true));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 60, 0, false, true, true));
                player.sendMessage("§4Furia Carmesí activada.");
            }
            case "spectral_dagger" -> {
                if (!useCooldown(player, id, 12)) return;
                Vector direction = player.getLocation().getDirection().normalize().multiply(1.65);
                direction.setY(Math.max(0.18, direction.getY() + 0.15));
                player.setVelocity(direction);
                player.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 30, 0, false, false, true));
                player.sendMessage("§8Paso espectral.");
            }
            case "bonebreaker" -> {
                if (!useCooldown(player, id, 18)) return;
                LivingEntity target = getTargetLivingEntity(player, 4.5);
                if (target == null) { player.sendMessage("§7No hay ningún objetivo cerca."); return; }
                target.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 100, 1, false, true, true));
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 50, 1, false, true, true));
                target.damage(3.0, player);
                player.sendMessage("§6Golpe quebrantahuesos.");
            }
            default -> { return; }
        }
        event.setCancelled(true);
    }

    private boolean useCooldown(Player player, String itemId, int seconds) {
        String key = player.getUniqueId() + ":" + itemId;
        long now = System.currentTimeMillis();
        long readyAt = abilityCooldowns.getOrDefault(key, 0L);
        if (readyAt > now) {
            player.sendMessage("§7Habilidad disponible en §c" + Math.max(1, (readyAt - now + 999) / 1000) + "s§7.");
            return false;
        }
        abilityCooldowns.put(key, now + seconds * 1000L);
        return true;
    }

    private String getCustomItemId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(itemIdKey, PersistentDataType.STRING);
    }

    private LivingEntity getTargetLivingEntity(Player player, double range) {
        LivingEntity best = null;
        double bestDistance = range * range;
        for (org.bukkit.entity.Entity entity : player.getNearbyEntities(range, range, range)) {
            if (!(entity instanceof LivingEntity living) || entity.equals(player)) continue;
            if (!player.hasLineOfSight(entity)) continue;
            double distance = player.getEyeLocation().distanceSquared(living.getEyeLocation());
            if (distance < bestDistance) { bestDistance = distance; best = living; }
        }
        return best;
    }

    private void registerRecipes() {
        ItemStack bloodIngot = makeItem("blood_ingot", Material.NETHERITE_SCRAP, "§cLingote de Sangre", "§7Material de fabricación de Bloodbath.");
        ItemStack abyssalCore = makeItem("abyssal_core", Material.HEART_OF_THE_SEA, "§5Núcleo Abismal", "§7Un núcleo oscuro de energía.");

        // Convert Death Rain drops into a crafting-grade Blood Ingot.
        ShapedRecipe bloodIngotRecipe = new ShapedRecipe(new NamespacedKey(this, "blood_ingot_from_drops"), bloodIngot);
        bloodIngotRecipe.shape("RFR", "R R", "   ");
        bloodIngotRecipe.setIngredient('R', Material.ROTTEN_FLESH);
        bloodIngotRecipe.setIngredient('F', Material.BLAZE_POWDER);
        Bukkit.addRecipe(bloodIngotRecipe);

        ItemStack blade = makeItem("bloodblade", Material.IRON_SWORD, "§4Espada Carmesí", "§7Clic derecho: Furia Carmesí.");
        ShapedRecipe bladeRecipe = new ShapedRecipe(new NamespacedKey(this, "bloodblade"), blade);
        bladeRecipe.shape(" R ", " R ", " S ");
        bladeRecipe.setIngredient('R', bloodIngot);
        bladeRecipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(bladeRecipe);

        ItemStack helmet = makeItem("wraith_helmet", Material.IRON_HELMET, "§8Yelmo Espectral", "§7Protección recuperada de la noche.");
        ShapedRecipe helmetRecipe = new ShapedRecipe(new NamespacedKey(this, "wraith_helmet"), helmet);
        helmetRecipe.shape("RRR", "R R", "   ");
        helmetRecipe.setIngredient('R', Material.PHANTOM_MEMBRANE);
        Bukkit.addRecipe(helmetRecipe);

        ItemStack dagger = makeItem("spectral_dagger", Material.IRON_SWORD, "§8Daga Espectral", "§7Clic derecho: Paso espectral.");
        ShapedRecipe daggerRecipe = new ShapedRecipe(new NamespacedKey(this, "spectral_dagger"), dagger);
        daggerRecipe.shape(" A ", " W ", "   ");
        daggerRecipe.setIngredient('A', Material.HEART_OF_THE_SEA);
        daggerRecipe.setIngredient('W', Material.PHANTOM_MEMBRANE);
        Bukkit.addRecipe(daggerRecipe);

        ItemStack axe = makeItem("bonebreaker", Material.IRON_AXE, "§6Quebrantahuesos", "§7Clic derecho: Golpe debilitante.");
        ShapedRecipe axeRecipe = new ShapedRecipe(new NamespacedKey(this, "bonebreaker"), axe);
        axeRecipe.shape("BB ", "BS ", " S ");
        axeRecipe.setIngredient('B', Material.BONE);
        axeRecipe.setIngredient('S', Material.STICK);
        Bukkit.addRecipe(axeRecipe);

        ShapedRecipe coreRecipe = new ShapedRecipe(new NamespacedKey(this, "abyssal_core"), abyssalCore);
        coreRecipe.shape("EDE", "DCD", "EDE");
        coreRecipe.setIngredient('E', Material.ECHO_SHARD);
        coreRecipe.setIngredient('D', Material.DIAMOND);
        coreRecipe.setIngredient('C', Material.PRISMARINE_CRYSTALS);
        Bukkit.addRecipe(coreRecipe);
    }

    @EventHandler
    public void onTotem(EntityResurrectEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        DamageSnapshot snapshot = recentDamage.get(player.getUniqueId());
        Location loc = player.getLocation();
        String cause = snapshot == null ? "Causa no identificada" : snapshot.cause;
        Location eventLoc = snapshot == null ? loc : snapshot.location;
        String worldName = eventLoc.getWorld() == null ? "desconocido" : eventLoc.getWorld().getName();

        Bukkit.broadcast(Component.text("✦ BLOODBATH SMP", TextColor.fromHexString("#FF3038")));
        Bukkit.broadcast(Component.text(player.getName() + " activó un Tótem de Inmortalidad.", NamedTextColor.WHITE));
        Bukkit.broadcast(Component.text("Causa: " + cause, NamedTextColor.RED));
        Bukkit.broadcast(Component.text("Mundo: " + worldName + " | X: " + eventLoc.getBlockX()
            + " Y: " + eventLoc.getBlockY() + " Z: " + eventLoc.getBlockZ(), NamedTextColor.GRAY));
        Bukkit.broadcast(Component.text("Día: " + getConfig().getInt("current-day", 1), NamedTextColor.DARK_RED));
    }

    // Keep the most recent damage source so the totem notice can include a useful cause.
    @EventHandler
    public void onDamage(org.bukkit.event.entity.EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        String cause = prettify(event.getCause().name());
        recentDamage.put(player.getUniqueId(), new DamageSnapshot(cause, player.getLocation().clone()));
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Keep snapshot briefly in case of unusual reconnect flows; normal cleanup happens on death.
    }

    private String prettify(String raw) {
        return switch (raw) {
            case "ENTITY_ATTACK" -> "ataque cuerpo a cuerpo";
            case "ENTITY_SWEEP_ATTACK" -> "ataque en barrido";
            case "PROJECTILE" -> "proyectil";
            case "FALL" -> "caída";
            case "LAVA" -> "lava";
            case "FIRE", "FIRE_TICK", "HOT_FLOOR" -> "fuego";
            case "DROWNING" -> "ahogamiento";
            case "BLOCK_EXPLOSION", "ENTITY_EXPLOSION" -> "explosión";
            case "VOID" -> "vacío";
            case "MAGIC", "POISON", "WITHER" -> "efecto mágico";
            case "SUFFOCATION" -> "asfixia";
            case "LIGHTNING" -> "rayo";
            case "STARVATION" -> "hambre";
            case "FREEZE" -> "congelación";
            default -> raw.toLowerCase().replace('_', ' ');
        };
    }

    private record DamageSnapshot(String cause, Location location) {}
}

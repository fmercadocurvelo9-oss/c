Bloodbath SMP v0.7.0

Proyecto de plugin Paper con progresión manual de 50 días, escalado exponencial, control de aparición de mobs, huevos de spawn configurables, Death Rain, anuncios de muerte/tótem y objetos con habilidades.

Comandos admin: /bloodbath day <1-50>, /bloodbath deathrain, /bloodbath stoprain, /bloodbath giveitems, /bloodbath recipes. Permiso: bloodbath.admin.

La Death Rain añade horas por cada muerte mientras está activa. Fórmula y crafteos: RECIPES_AND_TEXTURE_PACK.txt. Ajustes en src/main/resources/config.yml.

OBJETIVO solicitado: Minecraft Java 26.3, Paper y Java 25. El entorno usado para generar esta fuente no permite afirmar que esté compilada o probada contra ese servidor. No es un JAR listo para producción.


BLOODBATH SMP v0.8.1 — DROPS DE MOBS Y CRAFTEOS

ÉLITES (nombres que contienen “Bloodbath”, desde el día 5 según la probabilidad de élite):
- 100%: Lingote de Sangre (NETHERITE_SCRAP).
- Fragmento Óseo (BONE): 35% + hasta 25 puntos porcentuales según el día.
- Esencia Espectral (PHANTOM_MEMBRANE): 22% + bonus progresivo.
- Glándula de Plaga (SPIDER_EYE): 16% + bonus progresivo.
- Fragmento Abismal (ECHO_SHARD): 8% + medio bonus progresivo.
- Ascua de Alma (BLAZE_POWDER): 12% + medio bonus progresivo.
- Núcleo de Tormenta (PRISMARINE_CRYSTALS): desde día 25, 5% + medio bonus progresivo.

MOBS DE LA DEATH RAIN (“Lluvia de Sangre”):
- Fragmento de Sangre (ROTTEN_FLESH): 30% + bonus progresivo.
- Fragmento Óseo (BONE): 18% + bonus progresivo.
- Ascua de Alma (BLAZE_POWDER): desde día 15, 8% + medio bonus progresivo.

RECETAS NUEVAS/ACTUALIZADAS:
- Lingote de Sangre: R F R / R _ R / _ _ _ (R=carne podrida, F=polvo de blaze).
- Espada Carmesí: R / R / S (R=Lingote de Sangre, S=palo).
- Yelmo Espectral: W W W / W _ W / _ _ _ (W=membrana de phantom).
- Daga Espectral: _ A _ / _ W _ / _ _ _ (A=corazón del mar, W=membrana de phantom).
- Quebrantahuesos: B B _ / B S _ / _ S _ (B=hueso, S=palo).
- Núcleo Abismal: E D E / D C D / E D E (E=fragmento de eco, D=diamante, C=cristales de prismarina).

IMPORTANTE: las recetas de Bukkit comprueban el MATERIAL, no el nombre/PDC del ingrediente. Por eso los materiales base normales también sirven para estas recetas; los nombres personalizados identifican los drops y sus usos en el juego, pero no bloquean el crafteo a solo esos drops. Los drops especiales se añaden al morir a los mobs nombrados por el plugin. No se ha confirmado compilación o prueba en Paper 26.3/Java 25.

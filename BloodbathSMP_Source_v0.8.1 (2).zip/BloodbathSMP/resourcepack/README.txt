Bloodbath SMP resource pack v0.7.0
Contains custom item texture PNGs and transparent heart animation frames.
Install the ZIP in the Minecraft client's resourcepacks folder and enable it in Options > Resource Packs.
Important: the exact item-model bindings and pack format have not been validated in Minecraft Java 26.3. This pack contains the assets, but do not assume every custom item icon is already wired to the plugin's persistent item IDs.
See RECIPES_AND_TEXTURE_PACK.txt for recipes and the honest compatibility note.
